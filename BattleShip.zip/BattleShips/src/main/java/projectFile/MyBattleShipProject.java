package projectFile;

import java.util.*;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;

public class MyBattleShipProject {
    static char coordinates_player1[][] = new char[10][10];
    static String displayBoard = new String();
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        

//        int userXCord;
//        int userYcord;
//        
//        System.out.println("please can your enter a X value.");
//        userXCord= input.nextInt();
//        
//        System.out.println("please can your enter a Y value.");
//        userYcord = input.nextInt();
//        
//        System.out.println("Your cords are = " +"["+ userXCord + "," + userYcord+"]");
        //int cordinates [][] = new int [10][10];
        /*
        try {
            FileWriter writer = new FileWriter("BattleShipGame.txt", true);
            writer.write("hello world");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
         */
        try {
            FileReader reader = new FileReader("BattleShipGame.txt");
            int project;
            int i = 0;
            int j = 0;
            while ((project = reader.read()) != -1) {
                //System.out.println((char) project);
                char charFound = (char) project;

                //System.out.println("I=" + i + "_"+charFound+"_");
                if (charFound == '\n') {
                    j++;
//                    System.out.println("J="+j);
                    i = 0;

                } else {
                    coordinates_player1[i][j] = charFound;
                    i++;
                }

            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("enter your X coordinate");
        int x = input.nextInt();
        System.out.println("enter your Y coordinate");
        int y = input.nextInt();
        boolean inRange = false;
        //System.out.println(coordinates[y][x]);
        if (y < coordinates_player1.length) {
            if (x < coordinates_player1[y].length) {
                inRange = true;
                UpdateBoard(y, x);
                if (coordinates_player1[y][x] == 'O') {
                    System.out.println("You Missed");
                } else {
                    System.out.println("You hit a ship");
                    if(IsShipSunk(coordinates_player1[y][x]))
                    {
                        System.out.println("You have sunk a ship");
                    }
                }
            }
        }
        if (!inRange) {
            System.out.println("your shot has missed the battle field");
        }
        
    }
    static void UpdateBoard(int y, int x)
    {
       coordinates_player1[y][x] = 'X';
       for(int i = 0; i< coordinates_player1.length; i++)
       {        
            for(int j = 0; j< coordinates_player1[i].length; j++)
            {
                
                displayBoard+=coordinates_player1[i][j];
            }
            displayBoard+="\r\n";
       }
       System.out.print(displayBoard);
    }
    
    static boolean IsShipSunk(char shipType){
        
       for(int i = 0; i< coordinates_player1.length; i++)
       {
                   
            for(int j = 0; j< coordinates_player1[i].length; j++)
            {
                if(coordinates_player1[i][j] == shipType)
                {
                     return false;
                }
            }
       }
       
       return true;  

    }
    
    
}
