import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class HW2 {
    
    static int interval;
    static Timer timerCountdown;
    
    public static void main(String args[]) {
        
    Scanner input = new Scanner(System.in);
        System.out.println("Type in an amount of seconds : ");
        String seconds = input.next();
        int delay = 1000;
        int period = 1000;
        timerCountdown = new Timer();
        interval = Integer.parseInt(seconds);
        System.out.println(seconds);
        timerCountdown.scheduleAtFixedRate(new TimerTask(){
        
            public void run(){
                System.out.println(setInterval());
            }
        }, delay, period);
    }
        
      private static final int setInterval(){
            if(interval == 1)
               timerCountdown.cancel();
            return --interval;
        }
            }
        
        
        
    
    

