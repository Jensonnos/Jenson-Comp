
import java.util.Random;
import java.util.Scanner;

public class HW3 {

    public static int storeWScore;

    public static void main(String args[]) {

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        int[] rNumHolder = new int[10];
        int rNumber = new Random().nextInt(rNumHolder.length);
        int neededToWin = 3;
        int gotWrong;
        int ansCorrect = 0;

        System.out.println("This is a guessing game guess the right number to win or your be deleted!" + '\r' + "Get three correct and you can win." + '\r' + "The numbers are between 0 and 10 GL.");

        int[] newStoreWScore = new int[storeWScore];

        boolean correct;

       if (storeWScore != 5) {
            for (int i = 0; i < 5; i++) {
                
                
                rNumber = new Random().nextInt(rNumHolder.length);
                System.out.println("Take a shot!");
                System.out.println(rNumber);
                storeWScore = input.nextInt();
                correct = (rNumber == storeWScore);
                
                if (correct) {
                    System.out.println("You Scored!" + '\r');
                    ansCorrect++;
                } 
                else
                {
                    System.out.println("Wrong guess");
                }

                

            }
            if (ansCorrect >= neededToWin) {
                    System.out.println("you Won!");
                    //break;
                }
            else
            {
                System.out.println("you Lost!");
            }

        }

    }
}
