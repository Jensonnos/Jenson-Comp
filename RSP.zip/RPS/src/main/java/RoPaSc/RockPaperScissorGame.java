/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RoPaSc;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author jenson
 */
public class RockPaperScissorGame {

    public static void main(String args[]) {

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        String[] comp = {"Rock", "Paper", "Scissors"};
        int randGuess = new Random().nextInt(comp.length);
        
        System.out.println("Enter: Rock, Paper, Scissors");
        String userInp = input.next().toLowerCase();
        
        
        String expression = comp[randGuess].toLowerCase();
        System.out.println("The computer guessed: "+ expression+ ".");
        switch (expression) {
            case "rock":
            switch (userInp)
            {
                case "rock":
                    System.out.println("we guessed the same its a draw");
                    break;

                    case "paper":
                    System.out.println("I guessed paper I win.");
                    break;

                    case "scissors":
                    System.out.println("I guessed scissors you win");
                    break;
            }
        }
         switch (expression) {
        
            case "paper":
            switch(userInp)
            {
                    case "rock":
                        System.out.println("I guessed rock you win.");
                        break;
                        
                        case "paper":
                        System.out.println("we guessed the same its a draw.");
                        break;
                        
                        case "scissors":
                        System.out.println("I guessed scissors I win.");
                        break;
                }
         }
          switch (expression) {
            case "scissors":
            switch(userInp)
            {
                    case "rock":
                        System.out.println("I guessed rock I win.");
                        break;
                        
                        case "paper":
                        System.out.println("I guessed paper you win.");
                        break;
                        
                        case "scissors":
                        System.out.println("we guessed the same its a draw.");
                        break;
                }
            
        }
    }
}
