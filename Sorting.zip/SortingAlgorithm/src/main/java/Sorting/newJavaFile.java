
package Sorting;

import java.util.Arrays;
import java.util.Scanner;


public class newJavaFile {

    public static int n = 0;
    public static int userInputNumbers[];
    public static int newNumber[];
    
     public static void main(String args[]) {

        Scanner input = new Scanner(System.in);
        //ArrayList sorted = 
        System.out.println("How many numbers do you want to enter ? (must be at least 10)");
        
        if(input.hasNextInt())
        {
            n= input.nextInt();
        }
            if(n<10)
            {
                n = 10;
                System.out.println("Needed to be at least 10, so default set to 10.");
            }
        userInputNumbers = new int[n];
        for(int i = 0; i<n; i++)
        {
            System.out.println("enter the numbers now "+ i);           
            userInputNumbers[i] = input.nextInt();
        }
        System.out.println(Arrays.toString(userInputNumbers));
        
        numberSorting();
        
    }
    public static void numberSorting()
    {
        int sort, num;
        String numbersString;
        for(int i = 0; i<userInputNumbers.length - 1; i++)
        {
            for(int j = i+1; j <userInputNumbers.length; j++)
            {
                if(userInputNumbers[i]> userInputNumbers[j])
                {
                   // sort = userInputNumbers [j];
                   // userInputNumbers[j] = userInputNumbers[i];
                   // userInputNumbers[i] = sort;
                    int temp = userInputNumbers[i];
                    userInputNumbers[i] = userInputNumbers[j];
                    userInputNumbers[j] = temp;
                }
            }
        }
        numbersString = Arrays.toString(userInputNumbers);
        System.out.println(numbersString);
    }
        
}



