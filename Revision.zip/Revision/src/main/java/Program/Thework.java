package Program;

import java.util.Scanner;
import java.util.Random;

public class Thework {

    public static int storeScore;

    public static void main(String args[]) {

        Scanner input = new Scanner(System.in);

        System.out.println("Are You Ready To Play Basket ball?");
        String playerReady = input.next();

        if (playerReady.equalsIgnoreCase("yes")) {
            System.out.println("Okay lets go.");
        } else {
            System.out.println("You better get ready.");
        }

        scoring();

    }

    public static void scoring() {

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        int[] scoreHolder = new int[10];
        int rNumber = new Random().nextInt(scoreHolder.length);
        int neededToWin = 3;
        int gotWrong;
        int ansCorrect = 0;
        System.out.println(rNumber);

        //System.out.println("Method working");
        System.out.println("Time for you to shoot." + '\r' + "Guess a number correct to score a basket." + '\r' + "Get three correct and you can win." + '\r' + "The number has to be for 0 - 10");
        //storeScore = input.nextInt();

        int[] newStoreScore = new int[storeScore];

        boolean correct;// = (rNumber == storeScore);
       // boolean wrong = (rNumber != storeScore);

        if (storeScore != 5) {
            for (int i = 0; i < 5; i++) {
                
                rNumber = new Random().nextInt(scoreHolder.length);
                System.out.println("Take a shot! \r Random number is = " + rNumber);
                storeScore = input.nextInt();
                correct = (rNumber == storeScore);
                
                if (correct) {
                    System.out.println("You Scored!" + '\r');
                    ansCorrect++;
                } 
                else
                {
                    System.out.println("Wrong guess");
                }

                

            }
            if (ansCorrect == neededToWin) {
                    System.out.println("you Won!");
                    //break;
                }
            else
            {
                System.out.println("you Lost!");
            }

        }

    }
}
